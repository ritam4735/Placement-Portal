# Placement Portal

A role-based campus recruitment management web application built with Flask, Jinja2, Bootstrap, and SQLite.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Running the App](#running-the-app)
- [Default Login Credentials](#default-login-credentials)
- [Project Structure](#project-structure)
- [Features by Role](#features-by-role)
- [Notes](#notes)

---

## Prerequisites

- Python 3.10 or higher
- pip

---

## Installation

**1. Unzip and navigate into the project folder**

```bash
unzip PlacementPortal_v2.zip
cd PlacementPortal_v2
```

**2. (Recommended) Create and activate a virtual environment**

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

**3. Install dependencies**

```bash
pip install -r requirements.txt
```

**4. Initialise the database**

This creates all tables and seeds the admin user. Run this once before starting the app.

```bash
python create_db.py
```

---

## Running the App

```bash
python app.py
```

The app will start at **http://127.0.0.1:5000**

---

## Default Login Credentials

| Role  | Username | Password |
|-------|----------|----------|
| Admin | `admin`  | `admin`  |

> Company and Student accounts are created via the registration pages.  
> Company accounts require admin approval before they can log in.

---

## Project Structure

```
PlacementPortal_v2/
│
├── app.py                  # Flask app factory and entry point
├── config.py               # App configuration (secret key, DB path, uploads)
├── create_db.py            # Creates all DB tables and seeds admin user
├── extensions.py           # SQLAlchemy and Flask-Login initialisation
├── requirements.txt        # Python dependencies
├── portal.db               # SQLite database (auto-created by create_db.py)
│
├── models/
│   └── models.py           # All SQLAlchemy models (10 tables)
│
├── routes/
│   ├── auth_routes.py      # Login, logout, student & company registration
│   ├── admin_routes.py     # All admin functionalities
│   ├── company_routes.py   # Company dashboard, drives, applications
│   ├── student_routes.py   # Student dashboard, apply, profile, resume
│   └── main_routes.py      # Public landing page
│
├── templates/
│   ├── base.html           # Base layout (authenticated users)
│   ├── base_public.html    # Base layout (public pages)
│   ├── login.html
│   ├── register_student.html
│   ├── register_company.html
│   ├── index.html          # Public landing page
│   ├── admin/              # Admin templates
│   ├── company/            # Company templates
│   └── student/            # Student templates
│
├── static/
│   └── css/                # Custom stylesheets
│
└── uploads/                # Student resume PDFs (auto-created)
```

---

## Features by Role

### Admin
- Dashboard with live stats (students, companies, drives, applications, placements)
- Approve / reject / block / unblock / delete companies
- Approve / reject placement drives
- Search and filter students (name, email, roll no, enrollment no, CGPA, course, dept, batch, semester, placed status)
- View full student profiles and application history
- Edit student academic details
- Manage master data: Courses, Departments, Batches, Semesters
- Moderate and publish testimonials

### Company
- Register and await admin approval
- Create placement drives (title, description, eligibility, deadline)
- Edit or delete drives (only while Pending)
- Close approved drives
- View applicants per drive
- Update application status: Shortlisted → Selected / Rejected

### Student
- Self-register with full academic profile
- View all open, approved placement drives
- Apply for drives (duplicate applications are blocked)
- Upload PDF resume (max 2 MB)
- Edit personal profile (name, email, phone, age, CGPA)
- Track application statuses in real time

---

## Notes

- The database (`portal.db`) is created programmatically — do **not** create it manually via DB Browser or similar tools.
- Resume files are stored in the `uploads/` folder with a student-ID prefix for uniqueness.
- JavaScript is not used for any core functionality — all logic is handled server-side.
- To reset the database at any time, re-run `python create_db.py` (this will drop and recreate all tables).
